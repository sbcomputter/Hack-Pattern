clear
echo '                    
            __   __     _____   __       __       _____    
           /\_\ /_/\  /\_____\ /\_\     /\_\     ) ___ (   
          ( ( (_) ) )( (_____/( ( (    ( ( (    / /\_/\ \  
           \ \___/ /  \ \__\   \ \_\    \ \_\  / /_/ (_\ \ 
           / / _ \ \  / /__/_  / / /__  / / /__\ \ )_/ / / 
          ( (_( )_) )( (_____\( (_____(( (_____(\ \/_\/ /  
           \/_/ \_\/  \/_____/ \/_____/ \/_____/ )_____(   
                                                 
' | SBComputer
echo " "
echo "                             About"|SBComputer
echo " "
echo " We develop enthusiastic and qualified artist for designing and recreational activities prevailing within the country        "
echo ""
echo "                  Our Courses :- https://www.sbcomputter.com"| SBComputer
echo " "
